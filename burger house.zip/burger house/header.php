<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">

    <title><?php bloginfo('name')?></title>
    <!-- <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/stylesheet.css"> -->
    <style>
@import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Bebas+Neue&family=Montserrat:wght@600&display=swap');
</style>

<?php wp_head();?>
  </head>
  <body>


      <div class="block1">
<header>
<div class="container">
        <?php dynamic_sidebar('logo ');?>

<div class="box2">
  <div class="bikeblock">
<img class="bike" src="<?php echo get_template_directory_uri();?>/images/vector.png";>
<p id="p"> Express Delivery +1 234 567 890<p>
</div>
</div>
</div>


<div class="menulist";>
  <nav class="nav">
<?php wp_nav_menu( array( 'theme_location' => 'primary_menu' ) ); ?>
   </nav>
</div>
</header>
</div>
