<div class="block6";>


<div class="colum1">
<?php dynamic_sidebar('footer_col_1');?>
  </div>




<div class="colum2">
  <?php dynamic_sidebar('footer_col_2');?>
</div>
</div>
</div>

<?php wp_footer();?>
  </body>
</html>
